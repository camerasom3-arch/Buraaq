import React, { useState, useEffect } from 'react';
import { ArrowLeft, ArrowRight, Sparkles, Percent, Cpu } from 'lucide-react';
import { Language } from '../types';

interface PromoSliderProps {
  lang: Language;
  onExplore: (category: 'fashion' | 'electronics' | 'home' | 'beauty' | 'all') => void;
  openAiChat: () => void;
}

export default function PromoSlider({ lang, onExplore, openAiChat }: PromoSliderProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      id: 1,
      badge: lang === 'ar' ? 'تشكيلة جديدة' : lang === 'so' ? 'DHARKII UGU REER' : 'NEW COLLECTION',
      title: lang === 'ar' ? 'أحدث صيحات الموضة والأحذية الرياضية' : lang === 'so' ? 'Moodada & Kabaha Casriga Ah' : 'Epic Modern Fashion & Shoes',
      subtitle: lang === 'ar' ? 'احصل على خصم 30% على السترات القطنية والأحذية الرياضية الفاخرة.' : lang === 'so' ? 'Hel 30% qiimo dhimis ah funaanadaha cudbiga iyo kabaaha orodka.' : 'Get 30% discount on premium hoodies and athletic sneakers.',
      discount: '30% OFF',
      actionText: lang === 'ar' ? 'تسوق الآن' : lang === 'so' ? 'Hada iibso' : 'Shop Now',
      colorClass: 'from-orange-600 to-amber-500',
      icon: <Percent className="h-5 w-5 text-orange-200" />,
      onClick: () => onExplore('fashion'),
      image: "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1200&q=80"
    },
    {
      id: 2,
      badge: lang === 'ar' ? 'عروض الإلكترونيات' : lang === 'so' ? 'MAALINTA QALABKA' : 'ELECTRONICS BLITZ',
      title: lang === 'ar' ? 'أجهزة ذكية وصوتية متميزة' : lang === 'so' ? 'Tiknoolajiyadda Qof Kasta Rabo' : 'Audio & Precision Smart Gadgets',
      subtitle: lang === 'ar' ? 'سماعات رأس عازلة للضوضاء وساعات ذكية بنظام تحديد المواقع GPS.' : lang === 'so' ? 'Samaacado degan iyo saacado caqli-badan oo leh GPS tayo sare leh.' : 'Active Noise Cancelling headphones and modern GPS AMOLED smartwatches.',
      discount: 'SPECIAL PRICE',
      actionText: lang === 'ar' ? 'استكشف الأجهزة' : lang === 'so' ? 'Fura Qalabka' : 'Explore Gadgets',
      colorClass: 'from-blue-700 to-cyan-500',
      icon: <Cpu className="h-5 w-5 text-blue-200" />,
      onClick: () => onExplore('electronics'),
      image: "https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=1200&q=80"
    },
    {
      id: 3,
      badge: 'SomaMarket AI',
      title: lang === 'ar' ? 'تحدث مع مساعدنا الذكي للتسوق!' : lang === 'so' ? 'Tijaabi Adeegga Caawiyaha AI!' : 'Ask Our Personal AI Shopper!',
      subtitle: lang === 'ar' ? 'دع مساعد المحادثة المتطور بالذكاء الاصطناعي يختار نمطك المفضل أو يطبق الكوبون NABAD50.' : lang === 'so' ? 'Caawiyaheenna u dhashay AI wuxuu ku caawin doonaa inuu dambiisha ku daro alaabta.' : 'Let our advanced shopping chatbot select the perfect style, match colors, or apply code NABAD50.',
      discount: '50% OFF CODE: NABAD50',
      actionText: lang === 'ar' ? 'تحدث مع الذكاء الاصطناعي' : lang === 'so' ? 'La hadal AI' : 'Chat with AI Now',
      colorClass: 'from-purple-700 to-indigo-500',
      icon: <Sparkles className="h-5 w-5 text-purple-200 animate-pulse" />,
      onClick: openAiChat,
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  return (
    <div className="relative w-full overflow-hidden bg-gray-900 rounded-3xl min-h-[300px] sm:min-h-[360px] md:min-h-[400px] shadow-lg shadow-gray-200/50">
      
      {/* BACKGROUND IMAGE SLIDE */}
      <div 
        className="absolute inset-0 transition-all duration-700 ease-in-out scale-105"
        style={{
          backgroundImage: `linear-gradient(to right, rgba(15, 23, 42, 0.95) 40%, rgba(15, 23, 42, 0.3) 100%), url(${slides[currentSlide].image})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-12 py-10 md:py-16 flex flex-col justify-between h-full min-h-[300px] sm:min-h-[360px] md:min-h-[400px]">
        {/* UPPER TAG */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-white/10 backdrop-blur-md rounded-full border border-white/10">
            {slides[currentSlide].icon}
            <span className="text-[10px] sm:text-xs font-bold font-mono tracking-widest text-white uppercase">
              {slides[currentSlide].badge}
            </span>
          </div>
          <span className="px-2.5 py-1 bg-red-500 rounded-full text-[10px] font-extrabold tracking-wider text-white">
            {slides[currentSlide].discount}
          </span>
        </div>

        {/* INTERSTITIAL CONTENT */}
        <div className="max-w-xl my-4 sm:my-6">
          <h2 className="text-2xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {slides[currentSlide].title}
          </h2>
          <p className="mt-3 text-sm sm:text-base text-gray-300">
            {slides[currentSlide].subtitle}
          </p>
          <button
            id={`promo-action-btn-${slides[currentSlide].id}`}
            onClick={slides[currentSlide].onClick}
            className="mt-6 inline-flex items-center justify-center px-6 py-3 border border-transparent text-sm font-semibold rounded-full text-gray-900 bg-white hover:bg-orange-50 cursor-pointer shadow-md hover:shadow-lg hover:scale-102 transition-all"
          >
            {slides[currentSlide].actionText}
          </button>
        </div>

        {/* BOTTOM PAGINATION CONTROLS */}
        <div className="flex items-center justify-between w-full">
          {/* SLIDERS DOTS */}
          <div className="flex items-center gap-2">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`h-2.5 rounded-full transition-all cursor-pointer ${
                  currentSlide === index ? 'w-8 bg-orange-600' : 'w-2.5 bg-white/35 hover:bg-white/60'
                }`}
                title={`See Slide ${index + 1}`}
              />
            ))}
          </div>

          {/* ARROWS FOR MANUAL TOGGLE */}
          <div className="flex gap-2">
            <button
              id="promo-prev-btn"
              onClick={prevSlide}
              className="p-2 sm:p-2.5 rounded-full border border-white/10 text-white hover:bg-white/15 backdrop-blur-md cursor-pointer transition-all"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
            <button
              id="promo-next-btn"
              onClick={nextSlide}
              className="p-2 sm:p-2.5 rounded-full border border-white/10 text-white hover:bg-white/15 backdrop-blur-md cursor-pointer transition-all"
            >
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
