import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, MessageSquare, X, Send, ArrowRight, ShoppingCart, Check, Loader2, HelpCircle } from 'lucide-react';
import { Message, Product } from '../types';
import { PRODUCTS } from '../productsData';

interface AIConciergeProps {
  lang: 'so' | 'en';
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  onAddToCartDirect: (product: Product) => void;
  cartProductIds: string[];
}

export default function AIConcierge({
  lang,
  isOpen,
  setIsOpen,
  onAddToCartDirect,
  cartProductIds,
}: AIConciergeProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'bot',
      text: lang === 'so' 
        ? 'Haye! Waxaan ahay Caawiyahaaga SomaMarket. Waxaan kaa caawin karaa doorashada dharka, kabaha, qalabka guriga ama elektaroonigga. Ma haysaa wax aad raadinayso?' 
        : 'Welcome! I am your SomaMarket AI Shopping Assistant. Ask me anything about our categories, matching clothes, sneakers, or discounts!',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestions: lang === 'so' 
        ? ['Kaba orodka ugu fiican', 'Ma haysaa kuuban?', 'Funaanad cudbi ah']
        : ['Best running shoes', 'Do you have discounts?', 'Premium cotton hoodie']
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom on updates
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  // Adjust welcome message language when toggled
  useEffect(() => {
    setMessages(prev => {
      return prev.map(m => {
        if (m.id === 'welcome') {
          return {
            ...m,
            text: lang === 'so'
              ? 'Haye! Waxaan ahay Caawiyahaaga SomaMarket. Waxaan kaa caawin karaa doorashada dharka, kabaha, qalabka guriga ama elektaroonigga. Ma haysaa wax aad raadinayso?' 
              : 'Welcome! I am your SomaMarket AI Shopping Assistant. Ask me anything about our categories, matching clothes, sneakers, or discounts!',
            suggestions: lang === 'so' 
              ? ['Kaba orodka ugu fiican', 'Ma haysaa kuuban?', 'Funaanad cudbi ah']
              : ['Best running shoes', 'Do you have discounts?', 'Premium cotton hoodie']
          };
        }
        return m;
      });
    });
  }, [lang]);

  const handleSend = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMsg: Message = {
      id: 'user-' + Date.now(),
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const messagesPayload = [...messages, userMsg].map((m) => ({
        sender: m.sender,
        text: m.text,
      }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: messagesPayload }),
      });

      if (!res.ok) {
        throw new Error('API request failed');
      }

      const data = await res.json();
      let botText = data.text || '';
      
      // Parse for internal trigger tag: __ACTION_ADD_TO_CART__<id>
      let actionTagMatch = botText.match(/__ACTION_ADD_TO_CART__([a-zA-Z0-9]+)/);
      let productAction = undefined;

      if (actionTagMatch) {
        const prodId = actionTagMatch[1];
        // Clean text of the tag so the user doesn't see raw string token
        botText = botText.replace(/__ACTION_ADD_TO_CART__[a-zA-Z0-9]+/, '').trim();

        const matchProduct = PRODUCTS.find(p => p.id === prodId);
        if (matchProduct) {
          productAction = {
            type: 'add_to_cart' as const,
            productId: prodId,
            productName: lang === 'so' ? matchProduct.nameSo : matchProduct.name
          };
        }
      }

      setMessages(prev => [
        ...prev,
        {
          id: 'bot-' + Date.now(),
          sender: 'bot',
          text: botText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          productAction
        }
      ]);

    } catch (err) {
      console.error(err);
      setMessages(prev => [
        ...prev,
        {
          id: 'error-' + Date.now(),
          sender: 'bot',
          text: lang === 'so' 
            ? 'Waan ka xunahay, cilad farsamo ayaa dhacday. Fadlan hubi in GEMINI_API_KEY uu ku habaysan yahay Settings.' 
            : 'Sorry, I encountered a temporary network issue. Please check your internet or secrets configuration.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    handleSend(suggestion);
  };

  return (
    <div className="fixed bottom-6 right-6 z-45 flex flex-col items-end">
      {/* GLOWING TRIGGER LAUNCHER */}
      {!isOpen && (
        <button
          id="ai-chatbot-launcher-btn"
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-2 px-5 py-3.5 bg-gradient-to-r from-orange-600 via-orange-500 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-white rounded-full shadow-lg shadow-orange-500/20 hover:shadow-orange-500/30 transition-all duration-300 hover:scale-103 cursor-pointer select-none ring-4 ring-white"
        >
          <Sparkles className="h-5 w-5 animate-pulse text-white" />
          <span className="text-xs font-bold uppercase tracking-wider">
            {lang === 'so' ? 'Caawiyaha AI' : 'Live Shopper AI'}
          </span>
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500"></span>
          </span>
        </button>
      )}

      {/* CHAT PANEL BOX */}
      {isOpen && (
        <div className="w-[340px] sm:w-[380px] h-[500px] sm:h-[550px] bg-white rounded-3xl shadow-2xl border border-gray-100 flex flex-col overflow-hidden animate-slide-up relative">
          
          {/* DRAG-FREE PANEL HEADER */}
          <div className="p-4 bg-gradient-to-r from-gray-900 to-gray-800 text-white flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="h-9 w-9 bg-orange-500 rounded-xl flex items-center justify-center text-white font-bold leading-none shadow-md shadow-orange-500/10">
                <Sparkles className="h-4 w-4 text-white" />
              </div>
              <div>
                <h3 className="text-xs font-extrabold tracking-wide uppercase flex items-center gap-1.5 leading-none">
                  SomaMarket AI
                </h3>
                <span className="text-[10px] text-orange-400 flex items-center gap-1 leading-none mt-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" />
                  {lang === 'so' ? 'Hadda Firfircoon' : 'Active Shopper Assistant'}
                </span>
              </div>
            </div>

            <button
              id="close-ai-panel-btn"
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-full hover:bg-white/10 text-gray-300 hover:text-white transition-colors cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* CHATTING BUBBLES LIST */}
          <div 
            ref={scrollRef}
            className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50/50"
          >
            {messages.map((m) => {
              const isUser = m.sender === 'user';
              return (
                <div 
                  key={m.id}
                  className={`flex flex-col max-w-[85%] ${isUser ? 'ml-auto items-end animate-slice-right' : 'mr-auto items-start animate-slice-left'}`}
                >
                  <div className={`p-3.5 rounded-2xl text-xs leading-relaxed shadow-xs ${
                    isUser 
                      ? 'bg-orange-600 text-white rounded-tr-none' 
                      : 'bg-white border border-gray-100 text-gray-800 rounded-tl-none'
                  }`}>
                    <p className="whitespace-pre-line">{m.text}</p>
                    
                    {/* INJECTED TARGET ACTION IN CHAT */}
                    {!isUser && m.productAction && (
                      <div className="mt-3.5 p-3 bg-orange-50/70 border border-orange-100 rounded-xl flex items-center justify-between gap-3 animate-fade-in text-xs transition-all">
                        <span className="font-extrabold text-orange-800 flex items-center gap-1">
                          <ShoppingCart className="h-3.5 w-3.5 text-orange-600 shrink-0" />
                          {m.productAction.productName}
                        </span>

                        {/* ACCORDION ADD TRIGGERS */}
                        {cartProductIds.includes(m.productAction.productId) ? (
                          <span className="h-7 px-3 bg-green-550 border border-green-200 text-white rounded-full flex items-center gap-1 text-[10px] font-bold">
                            <Check className="h-3.5 w-3.5" />
                            <span>{lang === 'so' ? 'Ku Daray' : 'Added'}</span>
                          </span>
                        ) : (
                          <button
                            id={`ai-chat-add-btn-${m.productAction.productId}`}
                            onClick={() => {
                              const matchProd = PRODUCTS.find(p => p.id === m.productAction?.productId);
                              if (matchProd) {
                                onAddToCartDirect(matchProd);
                              }
                            }}
                            className="h-7 px-3 bg-orange-600 hover:bg-orange-550 active:scale-95 text-white rounded-full text-[10px] font-bold shadow-sm transition-all cursor-pointer flex items-center justify-center shrink-0"
                          >
                            <span>+ {lang === 'so' ? 'Dambiisha' : 'To Cart'}</span>
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                  
                  <span className="text-[9px] text-gray-400 mt-1 font-mono">{m.timestamp}</span>

                  {/* DISPLAY SUGGESTION BARS CHIPS */}
                  {!isUser && m.suggestions && m.suggestions.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-2.5">
                      {m.suggestions.map((sg, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSuggestionClick(sg)}
                          className="px-2.5 py-1 text-[10px] font-semibold text-orange-700 bg-orange-50 border border-orange-100/50 rounded-full hover:bg-orange-100/50 cursor-pointer transition-colors"
                        >
                          {sg}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}

            {/* MESSAGE LOADING PLACEHOLDER */}
            {isLoading && (
              <div className="mr-auto items-start max-w-[80%] flex flex-col gap-1.5">
                <div className="p-3.5 bg-white border border-gray-100 rounded-2xl rounded-tl-none flex items-center gap-1.5 text-xs text-gray-405 italic">
                  <Loader2 className="h-3.5 w-3.5 text-orange-500 animate-spin" />
                  <span>{lang === 'so' ? 'Caawiyaha ayaa qoraya...' : 'Personal Shopper thinking...'}</span>
                </div>
              </div>
            )}
          </div>

          {/* CHAT BAR TRIGGERS CHATS Input */}
          <div className="p-3 border-t border-gray-100 shrink-0 bg-white">
            <div className="flex gap-2">
              <input
                id="ai-chat-input"
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSend(input);
                }}
                disabled={isLoading}
                placeholder={lang === 'so' ? 'Sariiro kaba, hoodies...' : 'Ask recommended style...'}
                className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs focus:outline-hidden focus:ring-1 focus:ring-orange-500 focus:bg-white transition-all text-gray-800"
              />
              <button
                id="ai-send-btn"
                onClick={() => handleSend(input)}
                disabled={!input.trim() || isLoading}
                className="p-2 bg-orange-600 hover:bg-orange-500 disabled:bg-gray-200 text-white rounded-xl transition-all cursor-pointer shadow-md shadow-orange-500/10 flex items-center justify-center shrink-0"
                title="Send Message"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
            
            {/* INLINE ADVISORY KEY ALERT */}
            <p className="text-[9px] text-gray-400 text-center mt-2 leading-none flex items-center justify-center gap-1 font-sans">
              <HelpCircle className="h-3 w-3" />
              {lang === 'so' 
                ? 'Sheekaysigu wuxuu adeegsadaa Gemini 3.5 Flash server-side' 
                : 'Interactive queries served securely via Gemini-3.5-Flash'}
            </p>
          </div>

        </div>
      )}
    </div>
  );
}
