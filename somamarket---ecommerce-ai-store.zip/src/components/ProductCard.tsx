import React from 'react';
import { Heart, Star, Eye, ShoppingCart, Check } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  key?: React.Key;
  product: Product;
  lang: 'so' | 'en';
  isWishlisted: boolean;
  isAdded: boolean;
  onWishlistToggle: () => void;
  onAddToCart: () => void;
  onQuickView: () => void;
}

export default function ProductCard({
  product,
  lang,
  isWishlisted,
  isAdded,
  onWishlistToggle,
  onAddToCart,
  onQuickView,
}: ProductCardProps) {
  const finalPrice = product.price;
  const originalPrice = product.originalPrice;
  const hasDiscount = originalPrice ? originalPrice > finalPrice : false;
  const discountPercent = hasDiscount && originalPrice
    ? Math.round(((originalPrice - finalPrice) / originalPrice) * 100)
    : 0;

  return (
    <div className="group relative bg-white border border-gray-100 rounded-2xl overflow-hidden hover:shadow-lg hover:border-gray-200 transition-all duration-300 flex flex-col h-full">
      {/* BADGES & WISHLIST HEART OVERLAYS */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5 items-start">
        {product.tags.map((tag, i) => (
          <span
            key={i}
            className={`px-2.5 py-1 text-[10px] font-extrabold rounded-full uppercase tracking-wider shadow-xs ${
              tag.includes('Off') || tag.includes('Deal') || tag.includes('Qiimo')
                ? 'bg-red-500 text-white'
                : 'bg-orange-500 text-white'
            }`}
          >
            {tag === 'Best Seller' && lang === 'so' ? 'Ugu Caansan' : tag}
          </span>
        ))}
        {hasDiscount && (
          <span className="px-2 py-0.5 text-[10px] font-extrabold bg-red-600 text-white rounded-full">
            -{discountPercent}%
          </span>
        )}
      </div>

      <button
        id={`wish-btn-${product.id}`}
        onClick={(e) => {
          e.stopPropagation();
          onWishlistToggle();
        }}
        className={`absolute top-3 right-3 z-10 p-2 rounded-full backdrop-blur-md transition-all shadow-xs cursor-pointer ${
          isWishlisted
            ? 'bg-rose-50 text-rose-600 border border-rose-100'
            : 'bg-white/80 text-gray-400 hover:text-rose-600 hover:bg-white'
        }`}
        title={lang === 'so' ? 'Ku dar kuwa la doortay' : 'Add to Wishlist'}
      >
        <Heart className={`h-4.5 w-4.5 ${isWishlisted ? 'fill-current' : ''}`} />
      </button>

      {/* PRODUCT IMAGE SECTION */}
      <div 
        onClick={onQuickView}
        className="relative pt-[100%] bg-gray-50 overflow-hidden cursor-pointer shrink-0"
      >
        <img
          src={product.image}
          alt={lang === 'so' ? product.nameSo : product.name}
          className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        {/* QUICK VIEW SHADOW OVERLAY */}
        <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <button
            id={`quick-view-overlay-${product.id}`}
            onClick={(e) => {
              e.stopPropagation();
              onQuickView();
            }}
            className="flex items-center gap-2 px-4 py-2 bg-white/95 text-xs font-semibold text-gray-900 rounded-full shadow-md hover:bg-white scale-90 group-hover:scale-100 transition-all cursor-pointer"
          >
            <Eye className="h-4 w-4 text-orange-600" />
            <span>{lang === 'so' ? 'Eeg Faahfaahinta' : 'Quick View'}</span>
          </button>
        </div>
      </div>

      {/* DETAILS INFO */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* CATEGORY & STAR RATING */}
          <div className="flex items-center justify-between gap-2 mb-1">
            <span className="text-[10px] font-mono tracking-widest text-gray-400 uppercase">
              {lang === 'so' ? {
                fashion: 'Dharka',
                electronics: 'Tiknoolaji',
                home: 'Guriga',
                beauty: 'Quruxda'
              }[product.category] : product.category}
            </span>
            <div className="flex items-center gap-1">
              <Star className="h-3 w-3 text-amber-400 fill-current" />
              <span className="text-xs font-bold font-mono text-gray-700">{product.rating}</span>
              <span className="text-[10px] text-gray-400">({product.reviewsCount})</span>
            </div>
          </div>

          {/* PRODUCT NAME */}
          <h3 
            onClick={onQuickView}
            className="text-sm font-semibold text-gray-800 hover:text-orange-600 cursor-pointer line-clamp-2 transition-colors min-h-[40px]"
          >
            {lang === 'so' ? product.nameSo : product.name}
          </h3>

          {/* DESCRIPTION */}
          <p className="mt-1 text-xs text-gray-400 line-clamp-2">
            {lang === 'so' ? product.descriptionSo : product.description}
          </p>
        </div>

        {/* PRICING & CALL TO ACTION */}
        <div className="mt-4 pt-3 border-t border-gray-50 flex items-center justify-between gap-3">
          <div className="flex flex-col">
            {hasDiscount && (
              <span className="text-xs text-gray-400 line-through font-mono leading-none">
                ${originalPrice?.toFixed(2)}
              </span>
            )}
            <span className="text-base font-extrabold text-orange-600 font-mono leading-none">
              ${finalPrice.toFixed(2)}
            </span>
          </div>

          <button
            id={`add-cart-btn-${product.id}`}
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart();
            }}
            className={`flex items-center justify-center h-9 w-9 sm:w-auto sm:px-3 rounded-full transition-all cursor-pointer text-xs font-bold gap-1 shrink-0 ${
              isAdded
                ? 'bg-green-500 text-white shadow-md shadow-green-500/10'
                : 'bg-orange-600 text-white hover:bg-orange-500 shadow-md shadow-orange-500/10 active:scale-95'
            }`}
          >
            {isAdded ? (
              <>
                <Check className="h-4.5 w-4.5" />
                <span className="hidden sm:inline">{lang === 'so' ? 'Waa lagu daray' : 'Added'}</span>
              </>
            ) : (
              <>
                <ShoppingCart className="h-4 w-4" />
                <span className="hidden sm:inline">{lang === 'so' ? 'Ku dar' : 'Add to Cart'}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
