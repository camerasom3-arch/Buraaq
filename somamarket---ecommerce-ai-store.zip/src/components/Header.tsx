import React, { useState } from 'react';
import { ShoppingCart, Heart, Search, Globe, Sparkles, User, ShoppingBag } from 'lucide-react';
import { CartItem, Product } from '../types';

interface HeaderProps {
  lang: 'so' | 'en';
  setLang: (lang: 'so' | 'en') => void;
  cart: CartItem[];
  wishlist: Product[];
  setIsCartOpen: (open: boolean) => void;
  setIsWishlistOpen: (open: boolean) => void;
  setIsProfileOpen: (open: boolean) => void;
  onSearch: (query: string) => void;
}

export default function Header({
  lang,
  setLang,
  cart,
  wishlist,
  setIsCartOpen,
  setIsWishlistOpen,
  setIsProfileOpen,
  onSearch,
}: HeaderProps) {
  const [searchValue, setSearchValue] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchValue);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchValue(e.target.value);
    onSearch(e.target.value);
  };

  const cartItemsCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <header className="sticky top-0 z-40 w-full bg-white border-b border-gray-100 shadow-xs backdrop-blur-md bg-white/95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        
        {/* LOGO */}
        <div className="flex items-center gap-2 cursor-pointer shrink-0">
          <div className="h-10 w-10 dynamic-gradient rounded-xl bg-gradient-to-tr from-orange-500 via-orange-600 to-amber-500 flex items-center justify-center text-white font-bold text-lg shadow-md shadow-orange-500/10">
            <ShoppingBag className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-gray-900 flex items-center gap-1.5 leading-none">
              Soma<span className="text-orange-600">Market</span>
            </h1>
            <span className="text-[10px] font-mono tracking-widest text-gray-400 uppercase">AI Superstore</span>
          </div>
        </div>

        {/* SEARCH BAR (Amazon/Trendyol styled) */}
        <form onSubmit={handleSearchSubmit} className="hidden md:flex flex-1 max-w-lg relative group">
          <input
            id="desktop-search"
            type="text"
            value={searchValue}
            onChange={handleSearchChange}
            placeholder={
              lang === 'so'
                ? 'Raadi alaabta aad u baahan tahay...'
                : 'Search products you are looking for...'
            }
            className="w-full bg-gray-50/80 border border-gray-200 rounded-full py-2.5 pl-11 pr-4 text-sm text-gray-800 focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 focus:bg-white transition-all"
          />
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 group-focus-within:text-orange-500 transition-colors" />
        </form>

        {/* ACTIONS BAR */}
        <div className="flex items-center gap-2 sm:gap-4 shrink-0">
          {/* LANGUAGE SWITCHER */}
          <button
            id="lang-toggle-btn"
            onClick={() => setLang(lang === 'so' ? 'en' : 'so')}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-gray-600 hover:text-orange-600 border border-gray-100 bg-gray-50/50 hover:bg-gray-100/50 rounded-full transition-all cursor-pointer font-medium"
            title="Baddal luqadda / Switch Language"
          >
            <Globe className="h-3.5 w-3.5 text-gray-400" />
            <span>{lang === 'so' ? 'Somali 🇸🇴' : 'English 🇬🇧'}</span>
          </button>

          {/* WISHLIST ICON */}
          <button
            id="wishlist-drawer-btn"
            onClick={() => setIsWishlistOpen(true)}
            className="relative p-2.5 text-gray-600 hover:text-rose-600 hover:bg-rose-50 rounded-full transition-all cursor-pointer group"
          >
            <Heart className="h-5.5 w-5.5 group-hover:scale-105 transition-transform" />
            {wishlist.length > 0 && (
              <span className="absolute top-1.5 right-1.5 h-4.5 min-w-4.5 px-1 bg-rose-500 text-white font-sans text-[10px] font-bold rounded-full flex items-center justify-center animate-fade-in">
                {wishlist.length}
              </span>
            )}
          </button>

          {/* CART ICON */}
          <button
            id="cart-drawer-btn"
            onClick={() => setIsCartOpen(true)}
            className="relative p-2.5 text-gray-600 hover:text-orange-600 hover:bg-orange-50 rounded-full transition-all cursor-pointer group"
          >
            <ShoppingCart className="h-5.5 w-5.5 group-hover:scale-105 transition-transform" />
            {cartItemsCount > 0 && (
              <span className="absolute top-1.5 right-1.5 h-4.5 min-w-4.5 px-1 bg-orange-600 text-white font-sans text-[10px] font-bold rounded-full flex items-center justify-center animate-fade-in">
                {cartItemsCount}
              </span>
            )}
          </button>

          {/* PROFILE ICON */}
          <button
            id="profile-panel-btn"
            onClick={() => setIsProfileOpen(true)}
            className="flex items-center gap-1 p-2 text-gray-600 hover:text-orange-600 hover:bg-gray-50 rounded-lg transition-all cursor-pointer"
          >
            <div className="h-8 w-8 rounded-full bg-orange-100 flex items-center justify-center border border-orange-200">
              <User className="h-4 w-4 text-orange-600" />
            </div>
          </button>
        </div>
      </div>

      {/* MOBILE SEARCH BAR */}
      <div className="md:hidden px-4 pb-3 max-w-7xl mx-auto">
        <form onSubmit={handleSearchSubmit} className="relative group w-full">
          <input
            id="mobile-search"
            type="text"
            value={searchValue}
            onChange={handleSearchChange}
            placeholder={
              lang === 'so'
                ? 'Raadi alaabta aad u baahan tahay...'
                : 'Search products you are looking for...'
            }
            className="w-full bg-gray-50 border border-gray-200 rounded-full py-2 pl-10 pr-4 text-xs text-gray-800 focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all"
          />
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-gray-400 group-focus-within:text-orange-500 transition-colors" />
        </form>
      </div>
    </header>
  );
}
