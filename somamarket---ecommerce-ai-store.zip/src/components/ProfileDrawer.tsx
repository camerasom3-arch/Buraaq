import { X, User, ShoppingBag, Calendar, CheckSquare, Sparkles, Mail, CreditCard } from 'lucide-react';
import { Order } from '../types';

interface ProfileDrawerProps {
  lang: 'so' | 'en';
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
}

export default function ProfileDrawer({
  lang,
  isOpen,
  onClose,
  orders,
}: ProfileDrawerProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fade-in">
      {/* SHADOW BACKDROP */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* DRAWER PANEL */}
      <div className="fixed inset-y-0 right-0 max-w-md w-full bg-white shadow-2xl flex flex-col h-full border-l border-gray-100 z-10 animate-slide-left">
        
        {/* HEADER */}
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between shrink-0">
          <span className="text-base font-bold text-gray-900 flex items-center gap-2">
            <User className="h-5 w-5 text-orange-600" />
            {lang === 'so' ? 'Koontada & Dalabyada' : 'Account Profile'}
          </span>
          <button
            id="close-profile-btn"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-700 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* DETAILS LOGS */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5 text-xs">
          
          {/* USER PROFILE INFO SUMMARY */}
          <div className="p-4 bg-orange-50/20 border border-orange-100/50 rounded-2xl flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 font-bold text-sm border border-orange-200 uppercase shrink-0">
              CS
            </div>
            <div className="min-w-0">
              <h4 className="font-extrabold text-sm text-gray-900 truncate flex items-center gap-1">
                Camerasom User
                <Sparkles className="h-3.5 w-3.5 text-orange-500 fill-current" />
              </h4>
              <p className="text-gray-500 font-mono text-[10px] truncate flex items-center gap-1.5 mt-0.5">
                <Mail className="h-3 w-3 text-gray-400" />
                camerasom3@gmail.com
              </p>
            </div>
          </div>

          {/* HISTORIC ORDERS LIST */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-orange-600 flex items-center gap-1.5">
              <ShoppingBag className="h-4 w-4" />
              {lang === 'so' ? 'Taariikhda Dalabyada' : 'Your Order History'}
              <span className="h-5 px-2 bg-gray-100 text-gray-650 rounded-full flex items-center justify-center text-[10px] font-extrabold">
                {orders.length}
              </span>
            </h4>

            {orders.length === 0 ? (
              <div className="p-6 border border-dashed border-gray-200 rounded-2xl text-center flex flex-col items-center gap-2 text-gray-450 bg-gray-50/30">
                <CheckSquare className="h-6 w-6 text-gray-300" />
                <p className="font-semibold text-gray-800">{lang === 'so' ? 'Ma jiraan dalabyo dhowaan la sameeyay!' : 'No orders matched'}</p>
                <p className="text-[11px] text-gray-400">
                  {lang === 'so' 
                    ? 'Gelso alaabta dambiisha, xaqiiji faahfaahinta gaarsiinta si aad u tijaabiso dalabka.' 
                    : 'Add catalog products to your basket and complete a mock mobile payment checkout to log history.'}
                </p>
              </div>
            ) : (
              <div className="space-y-3.5">
                {orders.map((or) => (
                  <div 
                    key={or.id}
                    className="p-4 bg-white border border-gray-150 rounded-2xl shadow-xs space-y-3.5 hover:border-orange-200 transition-all"
                  >
                    {/* ID & DATE LINE */}
                    <div className="flex justify-between items-center pb-2.5 border-b border-gray-100 leading-none">
                      <div>
                        <span className="font-mono text-[10px] font-bold text-orange-600 bg-orange-50 px-2 py-0.5 rounded-md border border-orange-100">
                          ID: {or.id}
                        </span>
                        <div className="flex items-center gap-1 text-[9px] text-gray-400 font-mono mt-1.5">
                          <Calendar className="h-3 w-3" />
                          <span>{or.date}</span>
                        </div>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider ${
                        or.status === 'delivered' 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-orange-100 text-orange-700 animate-pulse'
                      }`}>
                        {lang === 'so' ? {
                          received: 'La helay',
                          preparing: 'La Diyaarinayaa',
                          shipped: 'Jidka ku jira',
                          delivered: 'La gaarsiiyay',
                        }[or.status] : or.status}
                      </span>
                    </div>

                    {/* ITEMS SAMPLES */}
                    <div className="space-y-2">
                      {or.items.map((it, i) => (
                        <div key={i} className="flex gap-2 items-center">
                          <img
                            src={it.product.image}
                            alt=""
                            className="h-7 w-7 rounded-md object-cover border border-gray-100 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div className="min-w-0 flex-1 flex justify-between items-center gap-2">
                            <span className="font-semibold text-gray-700 truncate text-[11px]">
                              {lang === 'so' ? it.product.nameSo : it.product.name}
                            </span>
                            <span className="font-mono text-gray-400 shrink-0 select-none">
                              x{it.quantity}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* BILL DETAILS */}
                    <div className="pt-2 border-t border-gray-100 flex items-center justify-between text-[11px] leading-none">
                      <div className="flex items-center gap-1 text-gray-400 font-sans">
                        <CreditCard className="h-3.5 w-3.5" />
                        <span>Checkout price:</span>
                      </div>
                      <span className="font-mono font-bold text-gray-850 text-xs text-orange-600">
                        ${or.total.toFixed(2)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {/* TIPS */}
          <div className="p-4 bg-gray-50 border border-gray-100 rounded-2xl text-[10px] text-gray-400 leading-relaxed shrink-0">
            <span className="font-bold text-gray-650 uppercase tracking-widest block mb-1">💡 CODES & COUPONS:</span>
            {lang === 'so' 
              ? 'Waxaad dambiisha ku dhex tijaabin kartaa koodhadhka qiimo-dhimista sida NABAD50 si aad u hesho 50% dhimis ama SOMA10 si aad u hesho 10% dhimis.' 
              : 'You can input promo codes in your basket like NABAD50 to deduct 50% discount or SOMA10 for 10% discount on entire card values.'}
          </div>

        </div>
      </div>
    </div>
  );
}
