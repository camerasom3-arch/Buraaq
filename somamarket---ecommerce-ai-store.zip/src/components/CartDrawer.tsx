import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, CreditCard, Ticket, Check } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  lang: 'so' | 'en';
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, q: number, color?: string, size?: string) => void;
  onRemoveItem: (productId: string, color?: string, size?: string) => void;
  onCheckout: (discountAmount: number, discountCode: string) => void;
}

export default function CartDrawer({
  lang,
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
}: CartDrawerProps) {
  const [coupon, setCoupon] = useState('');
  const [appliedDiscountCode, setAppliedDiscountCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [couponError, setCouponError] = useState('');
  const [couponSuccess, setCouponSuccess] = useState(false);

  if (!isOpen) return null;

  // Calculators
  const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const shipping = subtotal > 50 || subtotal === 0 ? 0 : 5.00;
  const discountVal = (subtotal * discountPercent) / 100;
  const grandTotal = subtotal + shipping - discountVal;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCoupon = coupon.trim().toUpperCase();
    
    if (cleanCoupon === 'NABAD50') {
      setAppliedDiscountCode('NABAD50');
      setDiscountPercent(50);
      setCouponSuccess(true);
      setCouponError('');
    } else if (cleanCoupon === 'SOMA10') {
      setAppliedDiscountCode('SOMA10');
      setDiscountPercent(10);
      setCouponSuccess(true);
      setCouponError('');
    } else {
      setCouponError(lang === 'so' ? 'Koodhkaas sax ma aha!' : 'Invalid coupon code!');
      setCouponSuccess(false);
    }
  };

  const handleProceedCheckout = () => {
    onCheckout(discountVal, appliedDiscountCode);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fade-in">
      {/* SHADOW BACKDROP */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* FLOATING DRAWER */}
      <div className="fixed inset-y-0 right-0 max-w-md w-full bg-white shadow-2xl flex flex-col h-full border-l border-gray-100 z-10 animate-slide-left">
        
        {/* DRAWER HEADER */}
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold text-gray-900">
              {lang === 'so' ? 'Dambiisha Adeega' : 'Your Shopping Cart'}
            </span>
            <span className="h-5.5 min-w-5.5 px-1.5 bg-orange-600 text-white text-[11px] font-extrabold rounded-full flex items-center justify-center">
              {cart.reduce((acc, item) => acc + item.quantity, 0)}
            </span>
          </div>
          <button
            id="close-cart-btn"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-700 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* ITEMS VIEW */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 gap-3">
              <div className="h-16 w-16 rounded-full bg-orange-50 flex items-center justify-center text-orange-600 mb-2">
                <Trash2 className="h-7 w-7" />
              </div>
              <p className="text-sm font-semibold text-gray-800">
                {lang === 'so' ? 'Dambiishaadu hadda waa eber!' : 'Your cart is currently empty'}
              </p>
              <p className="text-xs text-gray-400 max-w-xs">
                {lang === 'so' 
                  ? 'Fadlan ku dar qaar ka mid ah alaabtayada ugu fiican si aad u bilowdo!' 
                  : 'Browse our high-quality catalog items and add them here!'}
              </p>
              <button
                id="cart-browse-btn"
                onClick={onClose}
                className="mt-2 text-xs font-bold text-orange-600 hover:text-orange-500 border border-orange-200 hover:bg-orange-50/50 px-4 py-2 rounded-full cursor-pointer transition-all"
              >
                {lang === 'so' ? 'Haddaba Soo Adeego' : 'Start Shopping'}
              </button>
            </div>
          ) : (
            cart.map((item, idx) => (
              <div 
                key={`${item.product.id}-${item.selectedColor}-${item.selectedSize}`}
                className="flex gap-4 p-3.5 bg-gray-50/50 border border-gray-100 rounded-2xl relative hover:border-gray-200 transition-colors"
              >
                {/* THUMB */}
                <div className="h-18 w-18 rounded-xl bg-gray-100 overflow-hidden shrink-0 border border-gray-100">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="h-full w-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* TEXTS */}
                <div className="flex-1 flex flex-col justify-between min-w-0">
                  <div>
                    <h4 className="text-xs font-bold text-gray-850 truncate">
                      {lang === 'so' ? item.product.nameSo : item.product.name}
                    </h4>
                    
                    {/* SELECTED OPTIONS CHIPS */}
                    {(item.selectedColor || item.selectedSize) && (
                      <div className="flex flex-wrap gap-1.5 mt-1">
                        {item.selectedColor && (
                          <span className="text-[9px] font-semibold bg-white border border-gray-200 text-gray-500 px-1.5 py-0.5 rounded-full uppercase">
                            {item.selectedColor}
                          </span>
                        )}
                        {item.selectedSize && (
                          <span className="text-[9px] font-bold bg-white border border-gray-200 text-gray-500 px-1.5 py-0.5 rounded-full uppercase">
                            SIZE: {item.selectedSize}
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  {/* BOTTOM COUNTER CONTROLLER */}
                  <div className="flex items-center justify-between mt-2.5">
                    <div className="flex items-center border border-gray-200 bg-white rounded-lg h-7 scale-95 origin-left overflow-hidden">
                      <button
                        id={`cart-minus-${item.product.id}-${idx}`}
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1, item.selectedColor, item.selectedSize)}
                        className="px-2 h-full hover:bg-gray-100 text-gray-500 cursor-pointer"
                        title="Reduce"
                      >
                        <Minus className="h-3 w-3" />
                      </button>
                      <span className="px-2.5 text-xs font-bold font-mono text-gray-800">
                        {item.quantity}
                      </span>
                      <button
                        id={`cart-plus-${item.product.id}-${idx}`}
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1, item.selectedColor, item.selectedSize)}
                        className="px-2 h-full hover:bg-gray-100 text-gray-500 cursor-pointer"
                        title="Increase"
                      >
                        <Plus className="h-3 w-3" />
                      </button>
                    </div>

                    <span className="text-sm font-extrabold font-mono text-orange-600">
                      ${(item.product.price * item.quantity).toFixed(2)}
                    </span>
                  </div>
                </div>

                {/* DELETE ICON */}
                <button
                  id={`cart-delete-${item.product.id}-${idx}`}
                  onClick={() => onRemoveItem(item.product.id, item.selectedColor, item.selectedSize)}
                  className="absolute top-3 right-3 p-1 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-md transition-all cursor-pointer"
                  title="Remove Item"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* BOTTOM FORM: COUPONS & SUMMARY BREAKDOWNS */}
        {cart.length > 0 && (
          <div className="p-5 border-t border-gray-100 shrink-0 bg-gray-50/55 space-y-4">
            
            {/* COUPON INPUT */}
            <form onSubmit={handleApplyCoupon} className="flex gap-2">
              <div className="relative flex-1">
                <input
                  id="coupon-input"
                  type="text"
                  value={coupon}
                  onChange={(e) => setCoupon(e.target.value)}
                  placeholder={lang === 'so' ? 'Tusaale: NABAD50' : 'Try code: NABAD50'}
                  className="w-full bg-white border border-gray-200 rounded-xl py-2 pl-9 pr-3 text-xs placeholder-gray-450 focus:outline-hidden focus:ring-1 focus:ring-orange-500 focus:border-orange-500 transition-all uppercase"
                />
                <Ticket className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              </div>
              <button
                id="apply-coupon-btn"
                type="submit"
                className="px-4 py-2 bg-gray-900 text-white hover:bg-gray-850 rounded-xl text-xs font-bold cursor-pointer transition-colors shrink-0"
              >
                {lang === 'so' ? 'Geli' : 'Apply'}
              </button>
            </form>

            {/* ERROR OR SUCCESS OUTLETS */}
            {couponError && (
              <p className="text-[11px] font-semibold text-red-500 leading-none">{couponError}</p>
            )}
            {couponSuccess && (
              <div className="flex items-center gap-1.5 text-[11px] font-bold text-green-600 animate-fade-in">
                <Check className="h-3.5 w-3.5" />
                <span>{lang === 'so' ? 'Kuubanka waa la aqbalay (50% Qiimo dhimis)!' : 'Coupon applied! Enjoy 50% discount.'}</span>
              </div>
            )}

            {/* NUMERICAL CALCULATIONS SUMMARY */}
            <div className="space-y-2.5 text-xs text-gray-600 pt-1">
              <div className="flex justify-between items-center">
                <span>{lang === 'so' ? 'Wajibaadka alaabta (Subtotal)' : 'Subtotal'}</span>
                <span className="font-mono font-semibold text-gray-850">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span>{lang === 'so' ? 'Hawsha Gaarsiinta (Shipping)' : 'Shipping'}</span>
                <span className="font-mono font-semibold text-gray-850">
                  {shipping === 0 ? (
                    <span className="text-green-650 font-bold">{lang === 'so' ? 'Bilaash' : 'FREE'}</span>
                  ) : (
                    `$${shipping.toFixed(2)}`
                  )}
                </span>
              </div>

              {discountVal > 0 && (
                <div className="flex justify-between items-center text-green-600 font-bold">
                  <span>{lang === 'so' ? 'Qiimo Dhimis (Discount)' : 'Discount'} ({discountPercent}%)</span>
                  <span className="font-mono">-${discountVal.toFixed(2)}</span>
                </div>
              )}

              {/* TOTAL ROW */}
              <div className="flex justify-between items-center pt-3 border-t border-gray-200 text-sm font-extrabold text-gray-900">
                <span>{lang === 'so' ? 'Wadar Guud (Total)' : 'Grand Total'}</span>
                <span className="font-mono text-base text-orange-600">${grandTotal.toFixed(2)}</span>
              </div>
            </div>

            {/* RED DIRECT ACTION BUTTON */}
            <button
              id="proceed-checkout-btn"
              onClick={handleProceedCheckout}
              className="w-full flex items-center justify-center gap-2 h-11.5 bg-orange-600 hover:bg-orange-500 text-white rounded-xl text-xs font-bold shadow-md shadow-orange-500/10 cursor-pointer transition-all duration-200 hover:scale-101"
            >
              <CreditCard className="h-4 w-4" />
              <span>{lang === 'so' ? 'Dhammeystir Dalabka' : 'Proceed to Checkout'}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
