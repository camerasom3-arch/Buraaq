import { X, Heart, Trash2, ShoppingCart } from 'lucide-react';
import { Product } from '../types';

interface WishlistDrawerProps {
  lang: 'so' | 'en';
  isOpen: boolean;
  onClose: () => void;
  wishlist: Product[];
  onRemove: (productId: string) => void;
  onMoveToCart: (product: Product) => void;
}

export default function WishlistDrawer({
  lang,
  isOpen,
  onClose,
  wishlist,
  onRemove,
  onMoveToCart,
}: WishlistDrawerProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fade-in">
      {/* SHADOW BACKDROP */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* DRAWER PANEL */}
      <div className="fixed inset-y-0 right-0 max-w-md w-full bg-white shadow-2xl flex flex-col h-full border-l border-gray-100 z-10 animate-slide-left">
        
        {/* HEADER */}
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between shrink-0">
          <span className="text-base font-bold text-gray-900 flex items-center gap-2">
            <Heart className="h-5 w-5 text-rose-500 fill-rose-500" />
            {lang === 'so' ? 'Kuwa Aad Dooratay' : 'My Wishlist'}
            <span className="h-5 px-2 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center text-[10px] font-extrabold border border-rose-100">
              {wishlist.length}
            </span>
          </span>
          <button
            id="close-wish-btn"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-700 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* ITEMS */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {wishlist.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 gap-3">
              <div className="h-16 w-16 rounded-full bg-rose-50 flex items-center justify-center text-rose-500 mb-2">
                <Heart className="h-7 w-7" />
              </div>
              <p className="text-sm font-semibold text-gray-850">
                {lang === 'so' ? 'Liiskani hadda waa madhan yahay!' : 'Wishlist is empty'}
              </p>
              <p className="text-xs text-gray-400 max-w-xs leading-relaxed">
                {lang === 'so' 
                  ? 'Ganaax! Guji calaamadda wadnaha (heart) ee alaabta korkiisa ku taal si aad u kaydiso dhowaan adeegashada.' 
                  : 'Like your favorite items under the product grid by clicking the heart icon to persist them here.'}
              </p>
              <button
                id="wish-browse-btn"
                onClick={onClose}
                className="mt-2 text-xs font-bold text-rose-600 hover:text-rose-500 border border-rose-200 hover:bg-rose-50 px-4 py-2 rounded-full cursor-pointer transition-all"
              >
                {lang === 'so' ? 'Baar alaabaha' : 'Browse Catalog'}
              </button>
            </div>
          ) : (
            wishlist.map((it) => (
              <div 
                key={it.id}
                className="flex gap-4 p-3 bg-white border border-gray-100 rounded-2xl relative hover:border-gray-200 transition-colors"
              >
                {/* THUMB */}
                <div className="h-16 w-16 rounded-xl bg-gray-50 overflow-hidden shrink-0 border border-gray-100">
                  <img
                    src={it.image}
                    alt=""
                    className="h-full w-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* DETAILS */}
                <div className="flex-1 flex flex-col justify-between min-w-0 pr-6">
                  <div>
                    <h4 className="text-xs font-bold text-gray-850 truncate leading-tight">
                      {lang === 'so' ? it.nameSo : it.name}
                    </h4>
                    <span className="text-sm font-bold font-mono text-orange-600 mt-1 block">
                      ${it.price.toFixed(2)}
                    </span>
                  </div>

                  {/* QUICK MOVE TO CART BUTTON */}
                  <button
                    id={`wish-move-cart-${it.id}`}
                    onClick={() => onMoveToCart(it)}
                    className="mt-2.5 self-start flex items-center gap-1 px-3 py-1 bg-orange-600 hover:bg-orange-550 active:scale-95 text-white rounded-lg text-[10px] font-bold shadow-xs transition-all cursor-pointer h-7"
                  >
                    <ShoppingCart className="h-3 w-3" />
                    <span>{lang === 'so' ? 'Ku dar Dambiisha' : 'Move to Cart'}</span>
                  </button>
                </div>

                {/* TRASH DISCARD BUTTON */}
                <button
                  id={`wish-delete-${it.id}`}
                  onClick={() => onRemove(it.id)}
                  className="absolute top-3 right-3 p-1.5 text-gray-400 hover:text-rose-500 hover:bg-rose-50 rounded-md transition-all cursor-pointer"
                  title="Remove"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
}
