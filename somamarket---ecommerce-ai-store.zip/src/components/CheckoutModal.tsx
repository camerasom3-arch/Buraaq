import React, { useState } from 'react';
import { X, CheckCircle, Truck, PackageCheck, Calendar, ShieldCheck, CreditCard, RotateCw, Loader2 } from 'lucide-react';
import { CartItem, Order, Language } from '../types';

interface CheckoutModalProps {
  lang: Language;
  cart: CartItem[];
  discountAmount: number;
  discountCode: string;
  onClose: () => void;
  onSuccess: (newOrder: Order) => void;
  clearCart: () => void;
}

export default function CheckoutModal({
  lang,
  cart,
  discountAmount,
  discountCode,
  onClose,
  onSuccess,
  clearCart,
}: CheckoutModalProps) {
  const [step, setStep] = useState<'form' | 'processing' | 'success'>('form');
  
  // Form State
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('Mogadishu');
  const [address, setAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('evc_plus');
  const [mobileNumber, setMobileNumber] = useState('');
  const [formError, setFormError] = useState('');

  // Success state order tracking
  const [simulatedOrder, setSimulatedOrder] = useState<Order | null>(null);
  const [shippingStage, setShippingStage] = useState<'received' | 'preparing' | 'shipped' | 'delivered'>('received');

  const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const shipping = subtotal > 50 ? 0 : 5.00;
  const total = subtotal + shipping - discountAmount;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !phone || !address) {
      setFormError(
        lang === 'ar'
          ? 'برجاء تعبئة كافة الحقول المطلوبة للتوصيل!'
          : lang === 'so'
          ? 'Fadlan buuxi dhammaan meelaha banaan'
          : 'Please fill all fields'
      );
      return;
    }
    if (paymentMethod !== 'cod' && !mobileNumber) {
      setFormError(
        lang === 'ar'
          ? 'برجاء كتابة رقم المحفظة الإلكترونية لإتمام السداد!'
          : lang === 'so'
          ? 'Geli lambarka lacagta laga jarayo!'
          : 'Please enter your mobile payment number!'
      );
      return;
    }

    setFormError('');
    setStep('processing');

    // Simulate merchant processing
    setTimeout(() => {
      const uniqueId = 'SM-' + Math.floor(100000 + Math.random() * 900000);
      const createdOrder: Order = {
        id: uniqueId,
        items: [...cart],
        subtotal,
        shipping,
        discount: discountAmount,
        total,
        status: 'received',
        date: new Date().toLocaleDateString(lang === 'ar' ? 'ar-SA' : lang === 'so' ? 'so-SO' : 'en-US', {
          year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
        }),
        shippingDetails: {
          fullName,
          phone,
          city,
          address,
        },
        paymentMethod: paymentMethod === 'cod' 
          ? (lang === 'ar' ? 'الدفع نقداً عند الاستلام' : lang === 'so' ? 'Lacag bixinta dhalmada marka laguu keeno' : 'Cash on Delivery')
          : `Mobile Money Wallet (${paymentMethod.replace('_', ' ').toUpperCase()}) [${mobileNumber}]`,
      };

      setSimulatedOrder(createdOrder);
      setStep('success');
      onSuccess(createdOrder);
      clearCart();
    }, 2500);
  };

  const advanceSimulation = () => {
    if (shippingStage === 'received') setShippingStage('preparing');
    else if (shippingStage === 'preparing') setShippingStage('shipped');
    else if (shippingStage === 'shipped') setShippingStage('delivered');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6 animate-fade-in">
      {/* SHADOW OVERLAY */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={step === 'form' ? onClose : undefined}
      />

      <div className="relative bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-gray-100 animate-slide-up z-10 flex flex-col justify-between max-h-[92vh]">
        
        {/* HEADER BAR */}
        <div className={`px-6 py-4 border-b border-gray-100 flex items-center justify-between shrink-0 ${
          lang === 'ar' ? 'flex-row-reverse' : ''
        }`}>
          <span className={`text-base font-bold text-gray-900 flex items-center gap-2 ${
            lang === 'ar' ? 'flex-row-reverse' : ''
          }`}>
            <CreditCard className="h-5 w-5 text-orange-600" />
            {step === 'form' && (lang === 'ar' ? 'إتمام سداد قيمة الطلب' : lang === 'so' ? 'Dhammeystirka Iibsiga' : 'Checkout Order')}
            {step === 'processing' && (lang === 'ar' ? 'جاري السداد الآمن...' : lang === 'so' ? 'La shaqaynayo...' : 'Processing Payment...')}
            {step === 'success' && (lang === 'ar' ? 'تم استلام وتأكيد طلبك بنجاح!' : lang === 'so' ? 'Dalabkaagu waa Guulaystay!' : 'Order Dispatched')}
          </span>
          {step === 'form' && (
            <button
              id="close-checkout-btn"
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-700 transition-colors cursor-pointer"
            >
              <X className="h-4.5 w-4.5" />
            </button>
          )}
        </div>

        {/* COMPONENT STEPS */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          
          {/* STEP 1: CAPTURE DETAILS FORM */}
          {step === 'form' && (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs select-none">
              {formError && (
                <div className="p-3 bg-red-50 text-red-600 rounded-xl font-semibold border border-red-100">
                  {formError}
                </div>
              )}

              {/* SECTION: ADRESS INFO */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-orange-600">
                  {lang === 'so' ? '1. Cinwaanka Laguugu Keenayo' : '1. Delivery Address'}
                </h4>

                <div>
                  <label className="block text-[11px] font-bold text-gray-500 mb-1">{lang === 'so' ? 'Magacaga oo Buuxa' : 'Full Name'}</label>
                  <input
                    id="checkout-name"
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder={lang === 'so' ? 'Maxamed Axmed' : 'Mohamed Ahmed'}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2 px-3 text-sm focus:outline-hidden focus:ring-1 focus:ring-orange-500 focus:border-orange-500 transition-all"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-gray-500 mb-1">{lang === 'so' ? 'Lanbarka taleefanka' : 'Phone Number'}</label>
                    <input
                      id="checkout-phone"
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+252 61XXXXXXX"
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2 px-3 text-sm focus:outline-hidden focus:ring-1 focus:ring-orange-500 focus:border-orange-500 transition-all font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-gray-500 mb-1">{lang === 'so' ? 'Magaalada' : 'City'}</label>
                    <select
                      id="checkout-city"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2 px-3 text-sm focus:outline-hidden focus:ring-1 focus:ring-orange-500 focus:border-orange-500 transition-all"
                    >
                      <option value="Mogadishu">Mogadishu (Muqdisho) 🇸🇴</option>
                      <option value="Hargeisa">Hargeisa (Hargaysa) 🇸🇴</option>
                      <option value="Garowe">Garowe (Garoowe) 🇸🇴</option>
                      <option value="Bosaso">Bosaso (Boosaaso) 🇸🇴</option>
                      <option value="Kismayo">Kismayo (Kismaayo) 🇸🇴</option>
                      <option value="Galkayo">Galkayo (Gaalkacyo) 🇸🇴</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-gray-500 mb-1">{lang === 'so' ? 'Cinwaanka dhabta ah (Waddada/Xaafadda)' : 'Physical Address (Street/District)'}</label>
                  <input
                    id="checkout-address"
                    type="text"
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder={lang === 'so' ? 'Waddada Makka Al-Mukarrama, Xaafadda Hodan' : 'Maka Al-Mukarama Street, Hodan District'}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2 px-3 text-sm focus:outline-hidden focus:ring-1 focus:ring-orange-500 focus:border-orange-500 transition-all"
                  />
                </div>
              </div>

              {/* SECTION: PAYMENT OPTIONS */}
              <div className="space-y-3 pt-3 border-t border-gray-100">
                <h4 className="text-xs font-bold uppercase tracking-wider text-orange-600">
                  {lang === 'so' ? '2. Lacag Bixinta' : '2. Secure Payment'}
                </h4>

                <div className="grid grid-cols-2 gap-2.5">
                  <label className={`flex flex-col p-3 rounded-xl border text-center cursor-pointer transition-all ${
                    paymentMethod !== 'cod' ? 'border-orange-500 bg-orange-50/50' : 'border-gray-100 bg-white hover:border-gray-200'
                  }`}>
                    <input
                      id="opt-pay-evc"
                      type="radio"
                      name="payMethod"
                      value="evc_plus"
                      checked={paymentMethod === 'evc_plus'}
                      onChange={() => setPaymentMethod('evc_plus')}
                      className="sr-only"
                    />
                    <span className="font-extrabold text-xs text-gray-850">Mobile Money</span>
                    <span className="text-[10px] text-gray-400 mt-0.5">EVC & Zaad & Sahal</span>
                  </label>

                  <label className={`flex flex-col p-3 rounded-xl border text-center cursor-pointer transition-all ${
                    paymentMethod === 'cod' ? 'border-orange-500 bg-orange-50/50' : 'border-gray-100 bg-white hover:border-gray-200'
                  }`}>
                    <input
                      id="opt-pay-cod"
                      type="radio"
                      name="payMethod"
                      value="cod"
                      checked={paymentMethod === 'cod'}
                      onChange={() => setPaymentMethod('cod')}
                      className="sr-only"
                    />
                    <span className="font-extrabold text-xs text-gray-850">{lang === 'so' ? 'Caddaan markay timaado' : 'Cash on delivery'}</span>
                    <span className="text-[10px] text-gray-400 mt-0.5">{lang === 'so' ? 'Marka lagu gaarsiiyo' : 'No credit card needed'}</span>
                  </label>
                </div>

                {paymentMethod !== 'cod' && (
                  <div className="p-3 bg-orange-50/30 border border-orange-100/50 rounded-xl space-y-2 animate-fade-in text-[11px]">
                    <span className="font-bold text-gray-750 block">{lang === 'so' ? 'Lambarka laga goynayo lacagta (Mobile Wallet):' : 'Enter billing mobile number:'}</span>
                    <input
                      id="checkout-wallet-phone"
                      type="tel"
                      required
                      value={mobileNumber}
                      onChange={(e) => setMobileNumber(e.target.value)}
                      placeholder="e.g. 0615555555"
                      className="w-full bg-white border border-gray-200 rounded-lg py-1.5 px-3 text-xs focus:ring-1 focus:ring-orange-500 font-mono"
                    />
                    <p className="text-[9px] text-gray-400 leading-tight">
                      {lang === 'so' 
                        ? 'Waa ammaan. Waxaa laguu soo diri doonaa fariin PIN ee taleefankaaga si aad u xaqiijiso.' 
                        : 'A secure mobile transaction trigger will load on your device to enter your security PIN and approve.'}
                    </p>
                  </div>
                )}
              </div>

              {/* STATS BREAKDOWN */}
              <div className="pt-3 border-t border-gray-100 space-y-1.5 text-xs text-gray-500">
                <div className="flex justify-between">
                  <span>{lang === 'so' ? 'Alaabta wadarood' : 'Basket subtotal'}</span>
                  <span className="font-mono text-gray-800">${subtotal.toFixed(2)}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-green-600 font-bold">
                    <span>Discount code {discountCode}</span>
                    <span className="font-mono">-${discountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-gray-900 font-extrabold text-sm pt-2 border-t border-gray-100">
                  <span>{lang === 'so' ? 'Wadar Guud' : 'Grand Total'}</span>
                  <span className="font-mono text-orange-600 text-base">${total.toFixed(2)}</span>
                </div>
              </div>

              {/* ACTION TRIGGER BUTTON */}
              <button
                id="submit-order-btn"
                type="submit"
                className="w-full h-11 bg-orange-600 hover:bg-orange-500 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer transition-all hover:scale-101"
              >
                {lang === 'so' ? 'DIR DALABKA ADOOGADA' : 'CONFIRM & PAY'}
              </button>
            </form>
          )}

          {/* STEP 2: PROCESSING TRANSACTION LOADER */}
          {step === 'processing' && (
            <div className="py-16 flex flex-col items-center justify-center text-center gap-4 animate-pulse">
              <Loader2 className="h-12 w-12 text-orange-600 animate-spin" />
              <div>
                <h3 className="text-sm font-bold text-gray-900">
                  {lang === 'so' ? 'Waxaa la xaqiijinayaa lacag bixinta...' : 'Securing payment gateway...'}
                </h3>
                <p className="text-xs text-gray-400 mt-1 max-w-xs mx-auto">
                  {lang === 'so' 
                    ? 'Fadlan hubi taleefankaaga gacanta si aad u geliso PIN-kaaga xaqiijinta.' 
                    : 'We are processing the simulated digital wallet transfer. Please do not close or reload this page.'}
                </p>
              </div>
            </div>
          )}

          {/* STEP 3: ORDER SUCCESS & SIMULATOR TRACKING PANEL */}
          {step === 'success' && simulatedOrder && (
            <div className="space-y-6 animate-fade-in text-xs">
              
              {/* BRAND CARD */}
              <div className="p-4 bg-green-50/50 border border-green-100 rounded-2xl flex items-start gap-3.5">
                <CheckCircle className="h-7 w-7 text-green-500 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-extrabold text-green-700 leading-tight">
                    {lang === 'so' ? 'Dalabkaagu Wuu Guuleystay!' : 'Payment Complete Successfully!'}
                  </h3>
                  <span className="text-[10px] font-mono tracking-widest text-green-600 font-bold bg-white px-2 py-0.5 rounded-md border border-green-200 mt-1 inline-block">
                    ORDER ID: {simulatedOrder.id}
                  </span>
                  <p className="text-gray-500 mt-1.5 leading-tight">
                    {lang === 'so' 
                      ? 'Waad ku mahadsantahay iibsashada SomaMarket. Alaabadaada waxaa loo diyaarin doonaa dhowaan.' 
                      : 'Thank you for choosing SomaMarket. Your order receipt was created and has been logged.'}
                  </p>
                </div>
              </div>

              {/* TRACKING PROGRESS BAR */}
              <div className="space-y-4 pt-3 border-t border-gray-100 pb-1">
                <div className="flex justify-between items-center">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-orange-600 flex items-center gap-1">
                    <Truck className="h-4 w-4" />
                    {lang === 'so' ? 'Hadafka Keenista' : 'Order Tracking Journey'}
                  </h4>

                  {/* SIMULATION TRIGER UTILITY */}
                  {shippingStage !== 'delivered' && (
                    <button
                      id="simulate-next-stage-btn"
                      onClick={advanceSimulation}
                      className="flex items-center gap-1 px-2.5 py-1 text-[10px] font-bold text-orange-600 hover:bg-orange-50 border border-orange-200 rounded-full cursor-pointer transition-colors"
                    >
                      <RotateCw className="h-3 w-3 animate-spin" />
                      <span>{lang === 'so' ? 'Maree Tallaabada Xigta' : 'Simulate Next Stage'}</span>
                    </button>
                  )}
                </div>

                {/* VISUAL PIPELINE STAGES */}
                <div className="relative pl-7 space-y-6 before:absolute before:left-[11px] before:top-2.5 before:bottom-2.5 before:w-0.5 before:bg-gray-100">
                  {/* STAGE RECEIVED */}
                  <div className="relative">
                    <div className={`absolute -left-7 top-0.5 h-6 w-6 rounded-full flex items-center justify-center border-2 ${
                      shippingStage === 'received' || shippingStage === 'preparing' || shippingStage === 'shipped' || shippingStage === 'delivered'
                        ? 'bg-green-500 border-green-500 text-white' : 'bg-white border-gray-200 text-gray-300'
                    }`}>
                      <PackageCheck className="h-3.5 w-3.5" />
                    </div>
                    <div>
                      <h5 className="font-bold text-gray-800 leading-none">{lang === 'so' ? 'Dalabka la gudooray' : 'Order Received'}</h5>
                      <span className="text-[10px] text-gray-405 font-mono">{simulatedOrder.date}</span>
                    </div>
                  </div>

                  {/* STAGE PREPARING */}
                  <div className="relative">
                    <div className={`absolute -left-7 top-0.5 h-6 w-6 rounded-full flex items-center justify-center border-2 ${
                      shippingStage === 'preparing' || shippingStage === 'shipped' || shippingStage === 'delivered'
                        ? 'bg-green-500 border-green-500 text-white animate-pulse' : 'bg-white border-gray-200 text-gray-305'
                    }`}>
                      <Calendar className="h-3.5 w-3.5" />
                    </div>
                    <div>
                      <h5 className="font-bold text-gray-800 leading-none">{lang === 'so' ? 'Waa la diyaarinayaa' : 'Awaiting Packaging'}</h5>
                      <span className="text-[10px] text-gray-400">
                        {shippingStage === 'received' 
                          ? (lang === 'so' ? 'Xidhmada iyo diyaarinta miiska' : 'Awaiting merchant clearance')
                          : (lang === 'so' ? 'Xidhmada waa la diyaariyay dambiisha ku jira' : 'Finished sorting, boxing, and packing')}
                      </span>
                    </div>
                  </div>

                  {/* STAGE SHIPPED */}
                  <div className="relative">
                    <div className={`absolute -left-7 top-0.5 h-6 w-6 rounded-full flex items-center justify-center border-2 ${
                      shippingStage === 'shipped' || shippingStage === 'delivered'
                        ? 'bg-green-500 border-green-500 text-white animate-bounce' : 'bg-white border-gray-200 text-gray-305'
                    }`}>
                      <Truck className="h-3.5 w-3.5" />
                    </div>
                    <div>
                      <h5 className="font-bold text-gray-800 leading-none">{lang === 'so' ? 'Waa loo soo raray (Mootada / Baaburka)' : 'Dispatched / Out for Delivery'}</h5>
                      <span className="text-[10px] text-gray-400">
                        {shippingStage === 'shipped' 
                          ? (lang === 'so' ? `Mootada ama gaariga ayaa dhexda ku haya waddada Magaalada ${simulatedOrder.shippingDetails.city}` : `Agent is riding towards ${simulatedOrder.shippingDetails.city} distribution hub`)
                          : shippingStage === 'delivered' 
                            ? (lang === 'so' ? 'La rariyo wuu dhammaystirmay' : 'Rider completed navigation')
                            : (lang === 'so' ? 'Wali lama soo rarin' : 'Pending dispatch center load')}
                      </span>
                    </div>
                  </div>

                  {/* STAGE DELIVERED */}
                  <div className="relative">
                    <div className={`absolute -left-7 top-0.5 h-6 w-6 rounded-full flex items-center justify-center border-2 ${
                      shippingStage === 'delivered'
                        ? 'bg-green-500 border-green-500 text-white' : 'bg-white border-gray-200 text-gray-350'
                    }`}>
                      <ShieldCheck className="h-3.5 w-3.5" />
                    </div>
                    <div>
                      <h5 className="font-bold text-gray-800 leading-none">{lang === 'so' ? 'La Gaarsiiyay' : 'Delivered Safe'}</h5>
                      <span className="text-[10px] text-gray-400 font-semibold text-green-600">
                        {shippingStage === 'delivered' 
                          ? (lang === 'so' ? 'Alaabtii waad heshay! Waad ku mahadsan tahay.' : 'Package delivered securely at destination address!') 
                          : (lang === 'so' ? 'Keneenka dambe' : 'Requires handoff verification')}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* DETAILS SUMMARY */}
              <div className="p-4 bg-gray-55/40 border border-gray-100 rounded-2xl space-y-2">
                <span className="font-bold text-gray-800 uppercase tracking-widest text-[10px] block">{lang === 'so' ? 'Khadka rarka:' : 'Dispatched to:'}</span>
                <p className="text-gray-700 leading-none"><strong>{simulatedOrder.shippingDetails.fullName}</strong> - {simulatedOrder.shippingDetails.phone}</p>
                <p className="text-gray-500 leading-none">{simulatedOrder.shippingDetails.address}, {simulatedOrder.shippingDetails.city}</p>
                <p className="text-[10px] text-gray-400 mt-2.5 pt-2 border-t border-gray-150"><strong>{lang === 'so' ? 'Lacag bixinta:' : 'Paid via:'}</strong> {simulatedOrder.paymentMethod}</p>
              </div>

              {/* COMPLETE SUCCESS ACTION */}
              <button
                id="finish-order-btn"
                onClick={onClose}
                className="w-full h-11 bg-gray-900 hover:bg-gray-800 text-white rounded-xl text-xs font-bold cursor-pointer transition-all uppercase"
              >
                {lang === 'so' ? 'Dhariga ka Bax (Dharigii Weynaa)' : 'Back to Storefront'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
