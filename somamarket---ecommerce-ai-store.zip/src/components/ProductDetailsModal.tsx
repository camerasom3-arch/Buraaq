import React, { useState } from 'react';
import { X, Star, Heart, ShoppingCart, ShieldCheck, RefreshCw, Truck } from 'lucide-react';
import { Product, Language } from '../types';

interface ProductDetailsModalProps {
  product: Product;
  lang: Language;
  onClose: () => void;
  isWishlisted: boolean;
  onWishlistToggle: () => void;
  onAddToCart: (color?: string, size?: string) => void;
  isAdded: boolean;
}

export default function ProductDetailsModal({
  product,
  lang,
  onClose,
  isWishlisted,
  onWishlistToggle,
  onAddToCart,
  isAdded,
}: ProductDetailsModalProps) {
  const [selectedImage, setSelectedImage] = useState(product.image);
  const [selectedColor, setSelectedColor] = useState(product.options?.colors?.[0] || '');
  const [selectedSize, setSelectedSize] = useState(product.options?.sizes?.[0] || '');

  const hasDiscount = product.originalPrice ? product.originalPrice > product.price : false;

  const handleAddToCart = () => {
    onAddToCart(selectedColor, selectedSize);
  };

  const getTranslatedCategory = (cat: string) => {
    if (cat === 'fashion') return lang === 'ar' ? 'الأزياء والأحذية' : lang === 'so' ? 'Dharka' : 'Fashion';
    if (cat === 'electronics') return lang === 'ar' ? 'الأجهزة الإلكترونية' : lang === 'so' ? 'Tiknoolaji' : 'Electronics';
    if (cat === 'home') return lang === 'ar' ? 'المنزل والمطبخ' : lang === 'so' ? 'Guriga' : 'Home & Kitchen';
    if (cat === 'beauty') return lang === 'ar' ? 'الجمال والعناية الشخصية' : lang === 'so' ? 'Quruxda' : 'Beauty & Cosmetics';
    return cat;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6 md:p-10 animate-fade-in">
      {/* BACKGROUND BACKDROP */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* CONTENT BOX */}
      <div className="relative bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-gray-100 animate-slide-up flex flex-col md:flex-row">
        
        {/* CLOSE BUTTON */}
        <button
          id="close-modal-btn"
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-700 transition-colors shadow-xs cursor-pointer"
        >
          <X className="h-4.5 w-4.5" />
        </button>

        {/* LEFT COLUMN: IMAGES GALLERY */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 border-b md:border-b-0 md:border-r border-gray-100 flex flex-col gap-4 shrink-0">
          <div className="relative pt-[85%] bg-gray-50 rounded-2xl overflow-hidden shadow-xs border border-gray-50">
            <img
              src={selectedImage}
              alt={lang === 'ar' ? product.nameAr : lang === 'so' ? product.nameSo : product.name}
              className="absolute inset-0 w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* GALLERY THUMBNAILS */}
          {product.images && product.images.length > 1 && (
            <div className="flex items-center gap-3 overflow-x-auto pb-1">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImage(img)}
                  className={`h-16 w-16 rounded-xl overflow-hidden border-2 cursor-pointer shrink-0 transition-all ${
                    selectedImage === img
                      ? 'border-orange-500 scale-102 ring-4 ring-orange-500/10'
                      : 'border-gray-100 hover:border-gray-300'
                  }`}
                >
                  <img
                    src={img}
                    alt={`Gallery ${idx}`}
                    className="h-full w-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* RIGHT COLUMN: CORE PRODUCT DETAILS */}
        <div className={`w-full md:w-1/2 p-6 sm:p-8 flex flex-col justify-between gap-6 overflow-y-auto ${
          lang === 'ar' ? 'text-right' : 'text-left'
        }`}>
          <div>
            {/* BADGES & CAT */}
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-[10px] font-mono tracking-widest text-gray-400 uppercase">
                {getTranslatedCategory(product.category)}
              </span>
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 text-amber-400 fill-current" />
                <span className="text-sm font-bold font-mono text-gray-700">{product.rating}</span>
                <span className="text-xs text-gray-400">({product.reviewsCount} {lang === 'ar' ? 'تقييمات' : lang === 'so' ? 'faallo' : 'reviews'})</span>
              </div>
            </div>

            {/* TITLE */}
            <h2 className="text-xl sm:text-2xl font-extrabold text-gray-900 tracking-tight leading-snug">
              {lang === 'ar' ? product.nameAr : lang === 'so' ? product.nameSo : product.name}
            </h2>

            {/* PRICING */}
            <div className={`mt-4 flex items-baseline gap-3 ${lang === 'ar' ? 'flex-row-reverse justify-end' : ''}`}>
              <span className="text-2xl sm:text-3xl font-extrabold font-mono text-orange-600">
                ${product.price.toFixed(2)}
              </span>
              {hasDiscount && (
                <span className="text-base text-gray-400 font-mono line-through decoration-red-500">
                  ${product.originalPrice?.toFixed(2)}
                </span>
              )}
            </div>

            {/* DESCRIPTION */}
            <div className="mt-5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500">
                {lang === 'ar' ? 'تفاصيل وصـف المنتج' : lang === 'so' ? 'Ku saabsan alaabta' : 'Description'}
              </h4>
              <p className="mt-2 text-sm text-gray-650 leading-relaxed">
                {lang === 'ar' ? product.descriptionAr : lang === 'so' ? product.descriptionSo : product.description}
              </p>
            </div>

            {/* PRODUCT OPTIONS */}
            {product.options?.colors && product.options.colors.length > 0 && (
              <div className="mt-5">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500">
                  {lang === 'ar' ? 'اختر اللون' : lang === 'so' ? 'Dooro Midabka' : 'Select Color'}
                </h4>
                <div className={`mt-2.5 flex flex-wrap items-center gap-2 ${lang === 'ar' ? 'flex-row-reverse justify-end' : ''}`}>
                  {product.options.colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`px-3.5 py-1.5 text-xs font-semibold rounded-full border transition-all cursor-pointer ${
                        selectedColor === color
                          ? 'border-orange-500 bg-orange-50 text-orange-700 font-bold ring-2 ring-orange-500/10'
                          : 'border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {product.options?.sizes && product.options.sizes.length > 0 && (
              <div className="mt-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500">
                  {lang === 'ar' ? 'اختر المقاس' : lang === 'so' ? 'Dooro Sizing' : 'Select Size'}
                </h4>
                <div className={`mt-2.5 flex flex-wrap items-center gap-2 ${lang === 'ar' ? 'flex-row-reverse justify-end' : ''}`}>
                  {product.options.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`h-9 min-w-9 px-3 text-xs font-bold rounded-xl border flex items-center justify-center cursor-pointer transition-all ${
                        selectedSize === size
                          ? 'border-orange-500 bg-orange-50 text-orange-700 ring-2 ring-orange-500/10'
                          : 'border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* SELLER ASSURANCES */}
            <div className="mt-6 p-4 bg-gray-50/70 border border-gray-100 rounded-2xl grid grid-cols-3 gap-2 text-center text-[11px] text-gray-500 shrink-0">
              <div className="flex flex-col items-center gap-1 border-r border-gray-200">
                <Truck className="h-4 w-4 text-orange-500" />
                <span className="font-semibold text-gray-700">
                  {lang === 'ar' ? 'شحن سريع' : lang === 'so' ? 'Gaarsiin Degdeg ah' : 'Express Delivery'}
                </span>
                <span>
                  {lang === 'ar' ? 'خلال 12-48 ساعة' : lang === 'so' ? '12-48 saac' : '12-48 hours'}
                </span>
              </div>
              <div className="flex flex-col items-center gap-1 border-r border-gray-200">
                <ShieldCheck className="h-4 w-4 text-orange-500" />
                <span className="font-semibold text-gray-700">
                  {lang === 'ar' ? 'أصلي 100%' : lang === 'so' ? 'Hubaal Original' : '100% Original'}
                </span>
                <span>
                  {lang === 'ar' ? 'ضمان رسمي كامل' : lang === 'so' ? 'Dammaanad buuxda' : 'Guaranteed brand'}
                </span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <RefreshCw className="h-4 w-4 text-orange-500" />
                <span className="font-semibold text-gray-700">
                  {lang === 'ar' ? 'تبديل سهل' : lang === 'so' ? 'Bedelaad Fudud' : 'Easy Exchange'}
                </span>
                <span>
                  {lang === 'ar' ? 'خلال 7 أيام' : lang === 'so' ? 'Muddo 7 Cisho' : '7 days returns'}
                </span>
              </div>
            </div>
          </div>

          {/* ACTIONS TRIGGER */}
          <div className="flex items-center gap-3 pt-4 border-t border-gray-100 shrink-0 mt-4">
            <button
              id={`details-wish-btn-${product.id}`}
              onClick={onWishlistToggle}
              className={`p-3 rounded-2xl border transition-all cursor-pointer ${
                isWishlisted
                  ? 'border-rose-200 bg-rose-50 text-rose-500'
                  : 'border-gray-200 text-gray-400 hover:border-rose-200 hover:bg-rose-50/50 hover:text-rose-500'
              }`}
            >
              <Heart className={`h-5 w-5 ${isWishlisted ? 'fill-current' : ''}`} />
            </button>

            <button
              id={`details-add-cart-btn-${product.id}`}
              onClick={handleAddToCart}
              className={`flex-1 flex items-center justify-center gap-2 h-12 rounded-2xl cursor-pointer text-sm font-bold shadow-md transition-all ${
                isAdded
                  ? 'bg-green-500 text-white shadow-green-500/10'
                  : 'bg-orange-600 text-white hover:bg-orange-500 shadow-orange-500/10 hover:scale-101 active:scale-99'
              }`}
            >
              <ShoppingCart className="h-4 w-4" />
              <span>
                {isAdded
                  ? (lang === 'ar' ? 'تمت الإضافة للسلة' : lang === 'so' ? 'Waa Lagu Daray Dambiisha' : 'Added to Cart')
                  : (lang === 'ar' ? 'أضف إلى السلة' : lang === 'so' ? 'Ku dar Dambiisha' : 'Add to Shopping Cart')}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
